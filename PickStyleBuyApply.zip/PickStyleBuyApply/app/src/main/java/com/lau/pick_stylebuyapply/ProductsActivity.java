package com.lau.pick_stylebuyapply;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.security.auth.login.LoginException;

public class ProductsActivity extends AppCompatActivity{

    private ArrayAdapterProducts proArrAdapter;
    private ListView listView;
    ArrayList<Product> productsAdded = new ArrayList<>();
    int x;
    List<Product> productsList = new ArrayList<>();
    Intent intentBuy;
    @Override

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products);
        listView = (ListView) findViewById(R.id.productsList);
        proArrAdapter = new ArrayAdapterProducts(getApplicationContext(), R.layout.product_list_view_item);
        listView.setAdapter(proArrAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                itemAddedToCartShowMsg();
                productsAdded.add(productsList.get(i));
                //intentBuy.putExtra("id", arr);
                System.out.println(productsAdded);

//                Intent intent = new Intent(ProductsActivity.this, LogInActivity.class);
//                startActivity(intent);
            }
        });
        x= getIntent().getIntExtra("id", 0);
        Log.i("test2", String.valueOf(x));
       // Log.i("test2", String.valueOf(x));
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    getProducts();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            for(Product productData: productsList) {
                                proArrAdapter.add(productData);
                            }
                        }
                    });
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }

        });
        thread.start();


    }
    public void reviewReceipt(View view){
        intentBuy = new Intent(ProductsActivity.this, OrderActivity.class);
        intentBuy.putExtra("products", productsAdded);
        startActivity(intentBuy);
        //                Intent intent = new Intent(ProductsActivity.this, LogInActivity.class);
//                startActivity(intent);
    }

    public void itemAddedToCartShowMsg(){
        Toast.makeText(this, "1 item added to the cart", Toast.LENGTH_LONG).show();
    }
    public void getProducts() throws IOException {
            URL url = new URL("https://style-makeup-default-rtdb.firebaseio.com/styles/st"+ x +"/products.json");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            String input = "";
            while ((inputLine = in.readLine()) != null) {
                input = input + inputLine;
            }
            in.close();
            con.disconnect();
            System.out.println(input);
            JSONObject json = null;
            try {
                json = new JSONObject(input);
                Iterator<?> key = json.keys();

                while (key.hasNext()) {
                    System.out.println("TESTTTTTTTTTTTTTTTTTTT");
                    String individualKey = (String) key.next();
                    System.out.println(individualKey);
                    JSONObject part = (JSONObject) json.get(individualKey);
                    System.out.println(part);
                    Product currentProduct = new Product((String) part.get("image"), (String) part.get("proname"), (String) part.get("probrand"), (String) part.get("prodescription"), (String) part.get("proprice"));
                    productsList.add(currentProduct);
                    System.out.println("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD");
                    System.out.println(productsList);
                }
                System.out.println("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM");
                System.out.println(productsList.toString());
            } catch (JSONException e) {

                return;
            }

    }
}

