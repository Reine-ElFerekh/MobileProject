package com.lau.pick_stylebuyapply;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;

//on click{ task for register user execute url te3 users
//
public class LogInActivity extends AppCompatActivity {
    EditText username;

    EditText password;
    String username2 = "";
    Button btn;
    public class UsersTable extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... urls) {
            String result = "";
            URL url;
            HttpURLConnection urlConnection;
            try {
                username2 = LogInActivity.this.username.getText().toString();
                String usernameURL = "https://style-makeup-default-rtdb.firebaseio.com/users.json?orderBy=\"username\"&equalTo=\""+username2+"\"";
                url = new URL(usernameURL);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");

                InputStream in = urlConnection.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);
                int data = reader.read();
                while (data != -1) {
                    char current = (char) data;
                    result += current;
                    data = reader.read();
                }
                urlConnection.disconnect();
                return result;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
        protected void onPostExecute(String s){
            super.onPostExecute(s);
            try {
                JSONObject json = new JSONObject(s);
                Iterator<?> key = json.keys();
                String userKey = "";
                while(key.hasNext())
                {
                    userKey = (String) key.next();
                }
                if(userKey.isEmpty())
                {
                    show();
//                    Toast toast = Toast.makeText(getApplicationContext(), "Please fill in the fields to login",Toast.LENGTH_LONG);
//                    toast.setGravity(Gravity.CENTER_VERTICAL, 0,200);
//                    toast.show();
                }
                else
                {
                    GetUsers task2 = new GetUsers();
                    task2.execute("https://style-makeup-default-rtdb.firebaseio.com/users/" + userKey + ".json");
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    public class GetUsers extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... urls) {
            String result = "";
            HttpURLConnection urlConnection;
            URL url;
            try {
                url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                InputStream in = urlConnection.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);
                int data = reader.read();
                while (data != -1) {
                    char current = (char) data;
                    result += current;
                    data = reader.read();
                }
                urlConnection.disconnect();
                return result;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
        protected void onPostExecute(String s){
            super.onPostExecute(s);
            try{
                JSONObject json = new JSONObject(s);
                username2 = json.getString("username");
                if(json.getString("username").equalsIgnoreCase(username.getText().toString())) {
                    String hashed = hashPassword(password.getText().toString());
                    if (hashed.equalsIgnoreCase(json.getString("password")))
                    {
                        mapToActivity();
                    }
                    else
                    {
                        show();
                    }
                }else{
                    showWrongUsername();
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    public String hashPassword(String password){
        String pw_hash = BCrypt.hashpw(password, BCrypt.gensalt());
        return pw_hash;
    }
    public void show()
    {
        Toast.makeText(this, "Wrong password and/or username", Toast.LENGTH_SHORT).show();
    }
    public void showWrongUsername()
    {
        Toast.makeText(this, "Wrong username", Toast.LENGTH_SHORT).show();
    }
    public void mapToActivity()
    {
        Intent intent = new Intent(this, StylesActivity.class);
        startActivity(intent);
    }
    public void mapToSign(View view){
        Intent intent = new Intent(this, SignUpActivity.class);
        startActivity(intent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        username = (EditText) findViewById(R.id.username2);
        password = (EditText) findViewById(R.id.password2);
        btn = (Button) findViewById(R.id.loginbutton2);

    }
    public void Click(View view)
    {
        if(username.getText().toString().equals("") || password.getText().toString().equals("")) {
            Toast.makeText(this, "Please fill in the fields first", Toast.LENGTH_SHORT).show();
            return;
        }
        UsersTable task = new UsersTable();
        task.execute();
    }
}