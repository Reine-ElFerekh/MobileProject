package com.lau.pick_stylebuyapply;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class OrderActivity extends AppCompatActivity {
    private static final String TAG = "ListViewActivity";

    private ArrayAdapterBuy buyArrayAdapter;
    private ListView buylistView;
    ArrayList<String> buyProductNames;
    ArrayList<String> buyProductPrice;
    double total;
    ArrayList<String> pricesSplitted;
    private TextView totalText;
    //ArrayList<Product> buyArr;
    String price;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        buylistView = (ListView) findViewById(R.id.buyList);
        buyArrayAdapter = new ArrayAdapterBuy(getApplicationContext(), R.layout.listview_buy);
        buylistView.setAdapter(buyArrayAdapter);
        buyProductNames = new ArrayList<>();
        buyProductNames = getIntent().getStringArrayListExtra("products");
        Log.i("test3", String.valueOf(buyProductNames));
        buyProductPrice = new ArrayList<>();
        buyProductPrice = getIntent().getStringArrayListExtra("productsPrice");
        Log.i("test4", String.valueOf(buyProductPrice));
        pricesSplitted = new ArrayList<>();
//        for(int i = 0; i < buyProductPrice.size(); i++){
//            for(int j= 0; j< buyProductPrice.get(i).length(); j++) {
//                while(buyProductPrice.get(i).charAt(j) != '$') {
//                    price =
//                }
//            }
//
//        }

        for(int i= 0; i < buyProductPrice.size(); i++){
            StringBuffer sb = new StringBuffer(buyProductPrice.get(i));
            sb.deleteCharAt(sb.length() -1);
            total += Double.parseDouble(String.valueOf(sb));;
        }
        Log.i("TOTAL",String.valueOf(total));

        totalText =  findViewById(R.id.totalprice);
        totalText.setText(totalText.getText().toString() + total + "$");

//
//        buyArr = getIntent().getParcelableArrayListExtra();
//        Log.i("test2", String.valueOf(x));

        List<String[]> buyList = readData();
        for(String[] buyData:buyList ) {
            String buyName = buyData[0];
            String buyPrice = buyData[1];

            Product product = new Product(buyName,buyPrice);
            buyArrayAdapter.add(product);
        }
    }

    public List<String[]> readData(){
        List<String[]> resultList = new ArrayList<String[]>();
        for(int i = 0; i< buyProductNames.size(); i++) {
            String[] productBuy = new String[2];
            productBuy[0] = buyProductNames.get(i);
            productBuy[1] = buyProductPrice.get(i);

            resultList.add(productBuy);
        }


        return  resultList;
    }

}
