package com.lau.pick_stylebuyapply;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ArrayAdapterStyles extends ArrayAdapter<Style> {
    Style style;
    private List<Style> styleList = new ArrayList<Style>();

    public ArrayAdapterStyles(@NonNull Context context, int resource) {
        super(context, resource);
    }

    static class StyleViewHolder {
        ImageView styleImg;
        TextView styleName;
        TextView description;
    }

    @Override
    public void add(Style object) {
        styleList.add(object);
        super.add(object);
    }

    @Override
    public int getCount() {

        return this.styleList.size();
    }

    @Override
    public Style getItem(int index)
    {
        return this.styleList.get(index);
    }

    @Override
    public View getView(int i, View view, ViewGroup parent) {
        View row = view;
        StyleViewHolder viewHolder;
        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.listview_item, parent, false);
            viewHolder = new StyleViewHolder();
            viewHolder.styleImg = (ImageView) row.findViewById(R.id.styleImage);
            viewHolder.styleName = (TextView) row.findViewById(R.id.styleTitle);
            viewHolder.description = (TextView) row.findViewById(R.id.styleDescription);
            row.setTag(viewHolder);
        } else {
            viewHolder = (StyleViewHolder)row.getTag();
        }
        style = getItem(i);
        Bitmap bm = downloadImage(viewHolder.styleImg);
        viewHolder.styleName.setText(style.getTitle());
        viewHolder.description.setText(style.getDescription());
        return row;
    }

    public Bitmap downloadImage(ImageView styleImg){
        ImageDownloader task = new ImageDownloader();
        Bitmap downloadedImg;

        try{
            Log.e("Image URL", style.getImageURL());
            downloadedImg = task.execute(style.getImageURL()).get();
            styleImg.setImageBitmap(downloadedImg);
            return downloadedImg;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public class ImageDownloader extends AsyncTask<String, Void, Bitmap> {

        protected Bitmap doInBackground(String... urls){

            try{
                URL url = new URL(urls[0]);

                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                InputStream in = connection.getInputStream();
                Bitmap downloadedImage = BitmapFactory.decodeStream(in);
                return downloadedImage;

            }catch(Exception e){
                e.printStackTrace();
                return null;
            }
        }

    }
}
