package com.lau.pick_stylebuyapply;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class CardActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card);
    }
    public void addCard(View view){
        Intent intent = new Intent(CardActivity.this, CheckoutActivity.class);
        startActivity(intent);

    }
}