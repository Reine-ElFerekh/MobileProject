package com.lau.pick_stylebuyapply;

import android.widget.Button;

public class Product {
    private String productImg;
    private String productName;
    private String productBrand;
    private String productDescription;
    private String price;


    public Product(String productImg, String productName, String productBrand, String productDescription, String price) {
        super();
        this.setProductImg(productImg);
        this.setProductName(productName);
        this.setProductBrand(productBrand);
        this.setProductDescription(productDescription);
        this.setPrice(price);
    }

    public Product(String productName, String price) {
        this.productName = productName;
        this.setPrice(price);
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getProductDescription() {

        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductImg() {
        return productImg;
    }

    public void setProductImg(String productImg) {
        this.productImg = productImg;
    }

    public String getProductBrand() {
        return productBrand;
    }

    public void setProductBrand(String productBrand) {
        this.productBrand = productBrand;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productImg='" + productImg + '\'' +
                ", productName='" + productName + '\'' +
                ", productBrand='" + productBrand + '\'' +
                ", productDescription='" + productDescription + '\'' +
                ", price='" + price + '\'' +
                '}';
    }
}