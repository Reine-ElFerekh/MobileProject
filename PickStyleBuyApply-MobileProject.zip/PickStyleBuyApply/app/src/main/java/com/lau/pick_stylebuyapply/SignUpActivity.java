package com.lau.pick_stylebuyapply;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class SignUpActivity extends AppCompatActivity {
    EditText username;
    EditText password;
    int elements = 0;
    String bolTr;
    private EditText email;
    private TextView login;

    public class UsersID extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... urls) {
            String result = "";
            URL url;
            HttpURLConnection urlConnection;
            try {
                url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                InputStream in = urlConnection.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);
                int data = reader.read();
                while (data != -1) {
                    char current = (char) data;
                    result += current;
                    data = reader.read();
                    if (current == '}') {
                        elements++;
                    }
                }
                urlConnection.disconnect();
                return result;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                User task1 = new User();
                task1.execute("https://style-makeup-default-rtdb.firebaseio.com/users/us" + (elements) + ".json");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public class User extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... urls) {
            String result = "";
            URL url;
            HttpURLConnection urlConnection;
            try {
                Map<String, String> hmap = new HashMap<>();
                url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("PUT");
                urlConnection.setRequestProperty("Content-Type", "application/json; utf-8");
                hmap.put("username", username.getText().toString());
                hmap.put("email", email.getText().toString());
                hmap.put("password", hashPassword(password.getText().toString()));

                String jsonString = new JSONObject(hmap).toString();
                try (OutputStream out = urlConnection.getOutputStream()) {
                    byte[] in = jsonString.getBytes("utf-8");
                    out.write(in, 0, in.length);
                }
                try (BufferedReader bufferedReader = new BufferedReader(
                        new InputStreamReader(urlConnection.getInputStream(), "utf-8"))) {
                    StringBuilder res = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = bufferedReader.readLine()) != null) {
                        res.append(responseLine.trim());
                    }
                    bolTr = "true";
                    System.out.println(res.toString());
                }
                return bolTr;
            } catch (Exception e) {
                e.printStackTrace();
                return "false";
            }
        }

        protected void onPostExecute(String s) {
            Intent intent = new Intent(SignUpActivity.this, StylesActivity.class);
            startActivity(intent);

        }
    }

    public String hashPassword(String password) {
        String pw_hash = BCrypt.hashpw(password, BCrypt.gensalt());
        return pw_hash;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        username = findViewById(R.id.usernamesignup2);
        password = findViewById(R.id.passwordsignup2);
        email = findViewById(R.id.email2);
        login = findViewById(R.id.acclog);
        login.setText(Html.fromHtml(getString(R.string.already_have_account)));

    }

    public void mapp(View view) {
        Intent intent = new Intent(SignUpActivity.this, LogInActivity.class);
        startActivity(intent);
    }

    public void signUp(View view) {
        elements = 0;
        if (username.getText().toString().equals("") || email.getText().toString().equals("") || password.getText().toString().equals("")) {
            Toast.makeText(this, "Please fill in the fields first", Toast.LENGTH_SHORT).show();
            return;
        }
        UsersID task = new UsersID();
        task.execute("https://style-makeup-default-rtdb.firebaseio.com/users" + ".json");
    }
}
