package com.lau.pick_stylebuyapply;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class StylesActivity extends AppCompatActivity{

    private ArrayAdapterStyles arrAdapter;
    private ListView listView;
    List<Style> stylesList = new ArrayList<>();
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_styles);
        listView = (ListView) findViewById(R.id.listView);
        arrAdapter = new ArrayAdapterStyles(getApplicationContext(), R.layout.listview_item);
        listView.setAdapter(arrAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(StylesActivity.this, ProductsActivity.class);
                int sum = i + 1;
                intent.putExtra("id", sum);
                startActivity(intent);
            }
        });

        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    getStyles();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            for(Style styleData:stylesList ) {
                            arrAdapter.add(styleData);
                            }
                        }
                    });
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }).start();
    }

    public void getStyles() throws IOException {
        URL url = new URL("https://style-makeup-default-rtdb.firebaseio.com/styles.json");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        String input = "";
        while ((inputLine = in.readLine()) != null) {
            input = input + inputLine;
        }
        in.close();
        con.disconnect();
        System.out.println(input);
        JSONObject json=null;
        try{
            json = new JSONObject(input);
            Iterator<?> key = json.keys();

            while(key.hasNext()){
                String individualKey = (String) key.next();
                JSONObject part = (JSONObject) json.get(individualKey);
                Style currentStyle = new Style((String) part.get("imageurl"), (String) part.get("title"), (String) part.get("description"));
                stylesList.add(currentStyle);
            }
        }
        catch (JSONException e){

            return;
        }



    }
}

