package com.lau.pick_stylebuyapply;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class OrderActivity extends AppCompatActivity {

    private ArrayAdapterBuy buyArrayAdapter;
    private ListView buylistView;
    ArrayList<String> buyProductNames;
    ArrayList<String> buyProductPrice;
    double total;
    ArrayList<String> pricesSplitted;
    private TextView totalText;
    String price;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        buylistView = (ListView) findViewById(R.id.buyList);
        buyArrayAdapter = new ArrayAdapterBuy(getApplicationContext(), R.layout.listview_buy);
        buylistView.setAdapter(buyArrayAdapter);
        buyProductNames = new ArrayList<>();
        buyProductNames = getIntent().getStringArrayListExtra("products");
        buyProductPrice = new ArrayList<>();
        buyProductPrice = getIntent().getStringArrayListExtra("productsPrice");
        pricesSplitted = new ArrayList<>();


        for(int i= 0; i < buyProductPrice.size(); i++){
            StringBuffer sb = new StringBuffer(buyProductPrice.get(i));
            sb.deleteCharAt(sb.length() -1);
            total += Double.parseDouble(String.valueOf(sb));;
        }

        totalText =  findViewById(R.id.totalprice);
        totalText.setText(totalText.getText().toString() + total + "$");


        List<String[]> buyList = readData();
        for(String[] buyData:buyList ) {
            String buyName = buyData[0];
            String buyPrice = buyData[1];

            Product product = new Product(buyName,buyPrice);
            buyArrayAdapter.add(product);
        }
    }
    public void proceedToCheckout(View view){
        Intent intent = new Intent(OrderActivity.this, CheckoutActivity.class);
        startActivity(intent);

    }

    public List<String[]> readData(){
        List<String[]> resultList = new ArrayList<String[]>();
        for(int i = 0; i< buyProductNames.size(); i++) {
            String[] productBuy = new String[2];
            productBuy[0] = buyProductNames.get(i);
            productBuy[1] = buyProductPrice.get(i);

            resultList.add(productBuy);
        }


        return  resultList;
    }

}
