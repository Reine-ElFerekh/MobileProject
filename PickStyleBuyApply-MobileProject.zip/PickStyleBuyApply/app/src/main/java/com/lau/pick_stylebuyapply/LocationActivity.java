package com.lau.pick_stylebuyapply;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class LocationActivity extends AppCompatActivity {
    EditText address;
    String addressSent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
        address = (EditText) findViewById(R.id.editTextAddress);
    }
    public void save(View view){

        Intent intent = new Intent(LocationActivity.this, CheckoutActivity.class);
        addressSent = address.getText().toString();
        intent.putExtra("addressSent", addressSent);
        startActivity(intent);
    }
}