package com.lau.pick_stylebuyapply;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class CheckoutActivity extends AppCompatActivity {
    TextView address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
        address = (TextView) findViewById(R.id.location);
        String addressGet = getIntent().getStringExtra("addressSent");
        address.setText(address.getText().toString() + addressGet);


    }
    public void putLocation(View view){
        Intent intent = new Intent(CheckoutActivity.this, LocationActivity.class);
        startActivity(intent);
    }
    public void addCard(View view){
        Intent intent = new Intent(CheckoutActivity.this, CardActivity.class);
        startActivity(intent);
    }
    public void finish(View view){
        Intent intent = new Intent(CheckoutActivity.this, StylesActivity.class);
        startActivity(intent);
    }
}