package com.lau.pick_stylebuyapply;


import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ArrayAdapterProducts extends ArrayAdapter<Product> {
    Product product;
    private List<Product> productList = new ArrayList<Product>();
    public ArrayAdapterProducts(@NonNull Context context, int resource) {
        super(context, resource);
    }

    static class ProductViewHolder {
        ImageView productImg;
        TextView productName;
        TextView productBrand;
        TextView productDescription;
        TextView price;
    }
    @Override
    public void add(Product object) {
        productList.add(object);
        super.add(object);
    }
    @Override
    public int getCount() {

        return this.productList.size();
    }
    @Override
    public Product getItem(int index)
    {
        return this.productList.get(index);
    }

    @Override
    public View getView(int i, View view, ViewGroup parent) {
        View row = view;
        ProductViewHolder viewHolder;
        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.product_list_view_item, parent, false);
            viewHolder = new ProductViewHolder();
            viewHolder.productImg = (ImageView) row.findViewById(R.id.productImg);
            viewHolder.productName = (TextView) row.findViewById(R.id.productName);
            viewHolder.productBrand = (TextView) row.findViewById(R.id.productBrand);
            viewHolder.productDescription = (TextView) row.findViewById(R.id.productDescription);
            viewHolder.price = (TextView) row.findViewById(R.id.price);
            row.setTag(viewHolder);
        } else {
            viewHolder = (ProductViewHolder)row.getTag();
        }
        product = getItem(i);
        Bitmap bm = downloadImage(viewHolder.productImg);
        viewHolder.productName.setText(product.getProductName());
        viewHolder.productBrand.setText(product.getProductBrand());
        viewHolder.productDescription.setText(product.getProductDescription());
        viewHolder.price.setText(product.getPrice());
        return row;
    }

    public Bitmap downloadImage(ImageView productImg){
        ImageDownloader task = new ImageDownloader();
        Bitmap downloadedImg;

        try{
            Log.e("Image URL", product.getProductImg());
            downloadedImg = task.execute(product.getProductImg()).get();
            productImg.setImageBitmap(downloadedImg);
            return downloadedImg;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public class ImageDownloader extends AsyncTask<String, Void, Bitmap> {

        protected Bitmap doInBackground(String... urls){

            try{
                URL url = new URL(urls[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                InputStream in = connection.getInputStream();
                Bitmap downloadedImage = BitmapFactory.decodeStream(in);
                return downloadedImage;

            }catch(Exception e){
                e.printStackTrace();
                return null;
            }
        }

    }
}
